// Инициализация корзины из localStorage или пустого массива
const cart = JSON.parse(localStorage.getItem('cart')) || [];

// Сохраняем корзину в localStorage
const saveCart = () => {
    try {
        localStorage.setItem('cart', JSON.stringify(cart));
    } catch (error) {
        console.error('Ошибка при сохранении корзины:', error);
    }
};

// Добавление товара в корзину
const addToCart = (name, price, image) => {
    try {
        const existingItem = cart.find(item => item.name === name);
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push({ name, price, image, quantity: 1 });
        }
        saveCart();
        alert(`${name} добавлена в корзину!`);
        updateCart();
    } catch (error) {
        console.error('Ошибка при добавлении в корзину:', error);
        alert('Не удалось добавить книгу в корзину. Попробуйте снова.');
    }
};

// Обновление количества товара
const updateQuantity = (index, quantity) => {
    try {
        quantity = parseInt(quantity);
        if (isNaN(quantity) || quantity < 1) quantity = 1;
        cart[index].quantity = quantity;
        saveCart();
        updateCart();
    } catch (error) {
        console.error('Ошибка при обновлении количества:', error);
    }
};

// Удаление товара из корзины
const removeFromCart = (index) => {
    try {
        cart.splice(index, 1);
        saveCart();
        updateCart();
    } catch (error) {
        console.error('Ошибка при удалении из корзины:', error);
    }
};

// Обновление отображения корзины
const updateCart = () => {
    const cartItems = document.getElementById('cart-items');
    const cartTotal = document.getElementById('cart-total');

    // Если элементов таблицы или итога нет, выходим (например, на странице "О нас")
    if (!cartItems || !cartTotal) return;

    // Очищаем таблицу
    cartItems.innerHTML = '';

    // Рассчитываем общую сумму
    let total = 0;
    cart.forEach((item, index) => {
        const itemTotal = item.price * item.quantity;
        total += itemTotal;

        // Создаем строку таблицы
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${item.name}</td>
            <td>${item.price} руб.</td>
            <td>
                <input type="number" value="${item.quantity}" min="1" onchange="updateQuantity(${index}, this.value)">
            </td>
            <td>${itemTotal} руб.</td>
            <td><button class="btn btn-danger btn-sm" onclick="removeFromCart(${index})">Удалить</button></td>
        `;
        cartItems.appendChild(row);
    });

    // Обновляем итоговую сумму
    cartTotal.textContent = `${total} руб.`;
};

// Инициализация корзины при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
    updateCart();
});